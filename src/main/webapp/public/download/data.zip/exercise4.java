import java.util.*;
public class exercise4 {

    public static void countElement(int[] arr) {
        HashMap<Integer, Integer> hashMap = new HashMap<>();
        Set<Integer> mySet = new HashSet<>();
        for (Integer i : arr) {
            mySet.add(i);
            if (hashMap.containsKey(i)) {
                hashMap.put(i, hashMap.get(i) + 1);
            } else {
                hashMap.put(i, 1);
            }
        }

        for (Integer i : mySet) {
            System.out.printf("So lan xuat hien cua %d trong mang la: %d\n", i, hashMap.get(i));
        }
    }

    public static void main(String args[]) {
        int[] arr = {8, 10, 1, 6, 5, 8, 5};
        countElement(arr);
    }
}