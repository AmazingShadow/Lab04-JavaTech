public class exercise7 {

    public static void square(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            arr[i] *= arr[i];
        }
       
        for (Integer i : arr) {
            System.out.print(i + " ");
        }
    }

    public static void main(String args[]) {
        int[] arr = {8, 10, 1, 6, 5};
        square(arr);
    }
}