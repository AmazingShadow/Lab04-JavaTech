import java.util.*;

public class exercise10 {

    public static int thirdLargestElement(int[] arr) {
        Set<Integer> myset = new HashSet<>();
        for (Integer i : arr) {
            myset.add(i);
        }
        List<Integer> myList = new ArrayList<>();
        myList.addAll(myset);
        Collections.sort(myList, (a, b) -> {
            return b - a;
        });
        return myList.get(2);
    }

    public static void main(String[] args) {
        int[] arr = {8, 10, 1, 6, 5, 4 , 3, 8, 11, 15, 15, 14, 14, 12, 12};
        System.out.println("So lon thu 3 trong mang la: " + thirdLargestElement(arr));
    }
}
