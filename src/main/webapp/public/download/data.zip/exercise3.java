public class exercise3 {

    public static int sumOfArray(int[] arr) {
        int sum = 0;
        for (Integer i : arr) {
            if (i % 2 == 0) sum += i;
        }
        return sum;
    }

    public static void main(String args[]) {
        int[] arr = {8, 10, 1, 6, 5};
        System.out.println(sumOfArray(arr));
    }
}