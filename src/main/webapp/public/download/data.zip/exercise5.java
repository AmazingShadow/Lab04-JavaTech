public class exercise5 {

    public static boolean checkPrime(int number) {
        if (number < 2) return false;
        for (int i = 2; i <= Math.sqrt(number); i++) {
            if (number % i == 0) return false;
        }
        return true;
    }

    public static int countPrime(int[] arr) {
        int count = 0;
        for (Integer i : arr) {
            if (checkPrime(i)) {
                count += 1;
            }
        }
        return count;
    }

    public static void main(String args[]) {
        int[] arr = {8, 10, 1, 6, 5, 2, 3};
        System.out.println(countPrime(arr));
    }
}