public class exercise6 {

    public static int find(int[] arr, int k) {
        int index = -1;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == k) index = i;
        }
        return index;
    }

    public static void main(String args[]) {
        int[] arr = {8, 10, 1, 6, 5};
        System.out.println(find(arr, 1));
    }
}